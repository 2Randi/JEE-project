package fr.umontpellier.jeeS.model;

public enum Role {
	
	ETUDIANT,
	GESTIONNAIRE,
	ADMINISTRATEUR

}
